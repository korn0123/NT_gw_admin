import { prisma } from "@/lib/prisma";
import { DataTable } from "@/components/ui/data-table";

export default async function OrdersPage() {
  const data = await prisma.orders.findMany();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">
          Orders
        </h1>
      </div>

      <DataTable data={data} />
    </div>
  );
}